#define SIZEOF_LONG_LONG 8
#define SIZEOF_VOID_P 4
#define SIZEOF_SIZE_T 4
#define SIZEOF_TIME_T 8
#define SIZEOF_LONG 4
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
